
package com.mycompany.librarymanagementsystem;

import java.util.ArrayList;
import java.util.Scanner;

public class LibraryManagementSystem {

    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        Library library = new Library();

        library.addBook(new Book("Java Programming", "James Gosling", "111"));
        library.addBook(new Book("Python Basics", "Guido van Rossum", "222"));
        library.addMember(new Member("Alice", "M01"));
        library.addMember(new Member("Bob", "M02"));

        while (true) {
            System.out.println("\n=== Library Menu ===");
            System.out.println("1. Show all books");
            System.out.println("2. Borrow a book");
            System.out.println("3. Return a book");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            if (choice == 1) {
                library.showBooks();
            } else if (choice == 2) {
                System.out.print("Enter member ID: ");
                String memberId = scanner.nextLine();
                Member member = library.findMemberById(memberId);
                if (member == null) {
                    System.out.println("Member not found!");
                    continue;
                }
                System.out.print("Enter book title: ");
                String title = scanner.nextLine();
                Book book = library.findBookByTitle(title);
                if (book == null) {
                    System.out.println("Book not found!");
                    continue;
                }
                member.borrowBook(book);
            } else if (choice == 3) {
                System.out.print("Enter member ID: ");
                String memberId = scanner.nextLine();
                Member member = library.findMemberById(memberId);
                if (member == null) {
                    System.out.println("Member not found!");
                    continue;
                }
                System.out.print("Enter book title: ");
                String title = scanner.nextLine();
                Book book = library.findBookByTitle(title);
                if (book == null) {
                    System.out.println("Book not found!");
                    continue;
                }
                member.returnBook(book);
            } else if (choice == 4) {
                System.out.println("Goodbye!");
                break;
            }
        }
        scanner.close();
    }
}

    

